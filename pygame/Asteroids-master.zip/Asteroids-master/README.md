# Asteroids
Asteroid game made with python with pygame module
