# Author: Crystian Fernandes <crystian.fr@gmail.com>
# -*- coding: utf-8 -*-
# 20180325T0148Z

from funcoes import *

inicio = int(input("Entrar na calculadora? Digite 1 para sim, e 2 para não: "))
if inicio == 1:
    main()
elif inicio == 2:
    sys.exit(0)