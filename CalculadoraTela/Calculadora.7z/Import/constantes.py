# Author: Crystian Fernandes <crystian.fr@gmail.com>
# 20180325T0148Z

# constantes globais
# luminosidade solar em Watts
lum_sol = 3.828e+26

# raio solar em metro
rad_sol = 695500000

# temperatura solar em Kelvin
temp_sol = 5778

# massa solar em kg
mass_sol = 1.98855e+30

# constante de Stefan-Boltzmann
sig = 5.670367e-8

# unidade astronomica em metro
AU = 149597870691

# velocidade da luz em m/s
c = 299792458

# constante de Planck reduzida
hbar = 1.0545716823644548e-34

# constante gravitacional
G = 6.67408e-11