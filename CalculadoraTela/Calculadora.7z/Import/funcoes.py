# Author: Crystian Fernandes <crystian.fr@gmail.com>
# -*- coding: utf-8 -*-
# 20180325T0148Z
# as formulas da funcao blackhole() foram obtidas do site: http://xaonon.dyndns.org/hawking/

import math, sys
from constantes import *

# luminosidade e zona habitavel de uma estrela
def luminosity():
    print()
    print("Cálculo da luminosidade:\n")

    # calcula a luminosidade da estrela
    rad_star = float(input("Digite o raio da estrela em unidade de raio solar: "))
    temp_star = float(input("Digite a temperatura da estrela em Kelvin: "))
    radstar1 = rad_star*rad_sol
    total = ((radstar1/rad_sol)**2*(temp_star/temp_sol)**4)*lum_sol
    total0 = (((radstar1/rad_sol)**2*(temp_star/temp_sol)**4)*lum_sol)/lum_sol

    print("A luminosidade da estrela é:", total, "W")
    print("A luminosidade da estrela em unidade de luminosidade solar é:", total0)
    print()
    print("Cálculo da zona habitável:")
    print()

    # calcula a zona habitavel da estrela
    lumino = total
    r1 = float(input("Digite a temperatura de ebulição em Kelvin do elemento químico: "))
    r2 = float(input("Digite a temperatura de fusão em Kelvin do elemento químico: "))
    total1 = (((0.5*lumino)/(4*math.pi*sig*r1**4))**(0.5))/AU
    total2 = (((0.5*lumino)/(4*math.pi*sig*r2**4))**(0.5))/AU

    print()
    print("Borda interna da zona habitável:" , total1 , "AU")
    print("Borda externa da zona habitável:" , total2 , "AU")

# caracteristicas de um buraco negro
def blackhole():
    print()
    mass = float(input("Digite a massa do buraco negro em unidade de massa solar: "))
    bhmass = mass*mass_sol
    radius = bhmass*((2*G)/(c**2))
    radius_AU = radius/AU
    surface_area = (bhmass**2)*((16*math.pi*G**2)/(c**4))
    surface_gravity = (1/bhmass)*((c**4)/(4*G))
    surface_tides = (1/bhmass**2)*((c**6)/(4*G**2))
    entropia = bhmass**2*((4*math.pi*G)/(hbar*c*math.log(10)))
    temp = (1/bhmass)*((hbar*c**3)/(8*surface_gravity*math.pi*G))
    luminosidade = (1/bhmass**2)*((hbar*c**6)/(15360*math.pi*G**2))
    life_time = (bhmass**3)*((5120*math.pi*G**2)/(hbar*c**4))
    billion_years = life_time/3.154e+16
    
    print("O raio do buraco negro em unidade astronômica: ", radius_AU, "AU")
    print("O raio do buraco negro em metro: ", radius, "m")
    print("Área da superfície: ", surface_area, "m²")
    print("Aceleração gravitacional: ", surface_gravity, "m/s²")
    print("Força de maré: ", surface_tides, "m/s²/m")
    print("Entropia: ", entropia)
    print("Temperatura: ", temp, "K")
    print("Luminosidade: ", luminosidade, "W")
    print("Tempo de vida em bilhões de anos: ", billion_years)

# ano-luz para parsec
def ly_to_pc():
    print()
    ly = float(input("Digite a distancia em ano-luz: "))
    ly_to_pc = ly/3.2615637769
    print()
    print(ly, "anos-luz é igual a", ly_to_pc, "pc")

# parsec para ano luz
def pc_to_ly():
    print()
    pc = float(input("Digite a distancia em parsec: "))
    pc_to_ly = pc*3.2615637769
    print()
    print(pc, "parsec é igual a", pc_to_ly, "ly")

# metro para segundo-luz
def m_to_ls():
    print()
    metro = float(input("Digite a distancia em metro: "))
    m_to_sl = metro/299792458
    print()
    print(metro, "m é igual a", m_to_sl, "segundo-luz")

# segundo-luz para metro
def ls_to_m():
    print()
    s_luz = float(input("Digite a distancia em segundo-luz: "))
    sl_to_m = s_luz*c
    print()
    print(s_luz, "segundo-luz é igual a", sl_to_m, "m")

# ano-luz para metro
def ly_to_m():
    print()
    dist_luz = float(input("Digite a distancia em ano-luz: "))
    luz_to_m = 9460730472580800*dist_luz
    print()
    print(dist_luz, "ano-luz é igual a", luz_to_m, "m")

# metro para ano-luz
def m_to_ly():
    print()
    dist_m = float(input("Digite a distância em metro: "))
    m_to_ly = dist_m/1.0570008340246154e-16
    print()
    print(dist_m, "m é igual a", m_to_ly, "ano-luz")

# dilatacao do tempo
def time_dilation():
    print()
    tempo = float(input("Digite o tempo da viagem em segundo: "))
    velocidade = float(input("Digite a velociade em metro por segundo: "))
    resultado = (tempo)/((1-(velocidade**2/c**2)))**(1/2)
    print()
    print("A dilatação do tempo viajando a", velocidade, "m/s é", resultado, "s")

# limite de roche
def roche_limit():
    print()
    densidade1 = float(input("Digite a densidade do corpo principal em g/cm³: "))
    densidade2 = float(input("Digite a densidade do corpo secundario em g/cm³: "))
    dniae0 = densidade1*1000
    dniae1 = densidade2*1000
    raio = float(input("Digite o raio do corpo principal em kilometro: "))
    calculo0 = ((2)*(dniae0/dniae1))**(1/3)*raio
    calculo1 = calculo0*1000
    mtokm = calculo1/1000
    print()
    print("O limite de Roche do corpo principal é:", mtokm, "km")

# esfera de Hill
def hill_esphere():
    print()
    a = float(input("Digite o comprimento do eixo maior da orbita do corpo secundario em metro: "))
    e = float(input("Digite a excentricidade da orbita do corpo secundario: "))
    m = float(input("Digite a massa do corpo secundario em kg: "))
    M = float(input("Digite a massa do corpo principal em kg: "))
    calculo = (a)*(1-e)*((m)/(3*M))**(1/3)
    mtoAU = calculo/au
    mtokm = calculo/1000
    print()
    print("A esfera de Hill do corpo secundario é:", mtokm, "km ou", mtoAU, "AU")

# funcoes da calculadora cientifica
# maximo divisor comum
def mdc():
    print()
    primeiro_valor = int(input("Digite o primeiro valor: "))
    segundo_valor = int(input("Digite o segundo valor: "))
    result = math.gcd(primeiro_valor,segundo_valor)
    print("O máximo divisor comum de", primeiro_valor, "e", segundo_valor, " é ", result)

# raiz quadrada
def sqrt():
    print()
    radicando = int(input("Digite o valor do radicando: "))
    result = math.sqrt(radicando)
    print()
    print("A raiz quadrada de", radicando,"é", result)

# logaritmo
def log():
    print()
    logaritmando = input("Digite o valor do logaritmando: ")
    base = input("Digite o valor da base: ")
    result = math.log(logaritmando[base])
    print("O logaritmo de", logaritmando," na base ", base, " é ", result)
    
# Exponenciacao
def exponenciacao():
    print()
    base = float(input("Digite a base: "))
    expoente = float(input("Digite o expoente: "))
    result = math.pow(base, expoente)
    print(base, "elevado a", expoente, "é igual a", result)

# funcao para sair do programa
def saida():
    print()
    sair = int(input("Sair? Digite 1 para sair, e 2 para continuar na calculadora: "))
    if sair == 1:
        sys.exit(0)
    elif sair == 2:
        main()

# funcao principal
def main():
    print()
    print("Digite 1 para Calculadora astronomica, e 2 para Calculadora cientifica\n")
    var = int(input("Digite uma opcao: "))

    # calculadora astronomica
    if var == 1:
        print()
        print("1 - Calcular a luminosidade e a zona habitavel de uma estrela")
        print("2 - Caracteristicas de um buraco negro com base em sua massa")
        print("3 - Converter ano-luz para parsec")
        print("4 - Converter parsec para ano-luz")
        print("5 - Converter metro para segundo-luz")
        print("6 - Converter segundo-luz para metro")
        print("7 - Converter ano-luz para metro")
        print("8 - Converter metro para ano-luz")
        print("9 - Calcular a dilatacao do tempo")
        print("10 - Calcular limite de roche")
        print("11 - Calcular o raio da esfera de Hill")
        print()
        opcao = int(input("Digite uma opcao: "))
        if opcao == 1:
            luminosity()
        elif opcao == 2:
            blackhole()
        elif opcao == 3:
            ly_to_pc()
        elif opcao == 4:
            pc_to_ly()
        elif opcao == 5:
            m_to_ls()
        elif opcao == 6:
            ls_to_m()
        elif opcao == 7:
            ly_to_m()
        elif opcao == 8:
            m_to_ly()
        elif opcao == 9:
            time_dilation()
        elif opcao == 10:
            roche_limit()
        elif opcao == 11:
            hill_esphere()

        saida()

# calculadora cientifica
    elif var == 2:
        print()
        print("1 - Maximo divisor comum")
        print("2 - Raiz quadrada")
        print("3 - Logaritmo")
        print("4 - Exponenciacao")
        print()
        opcao = int(input("Digite uma opcao: "))
        if opcao == 1:
            mdc()
        elif opcao == 2:
            sqrt()
        elif opcao == 3:
            log()
        elif opcao == 4:
            exponenciacao()
        
        saida()
